<?php
include 'conexion.php';
  $mysqli = new mysqli($host, $user, $pw,$bd);
?>
<html lang="en">
<head>
    <meta chaset="UTf-8">
    <meta name="viewport" content="width=device-width,initial-scale1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title> REGISTRATE | CUMBAYA STORE </title>    
    
</head>
<body> 
    <section class="form·register">
       <h4>REGISTRATE</h4> 
       <form id="form" method="post" action="registar.php"> 
        <input class="controls" type="text" name="nombres" id="nombres" placeholder="Ingrese su Nombre">
        <input class="controls" type="text" name="apellidos" id="apellidos" placeholder="Ingrese su Apellido">
        <input class="controls" type="text" name="correo" id="correo" placeholder="Ingrese su correo">
        <input class="controls" type="password" name="contrasena" id="contraseña" placeholder="Ingrese su clave">
       <p>Estoy de acuerdo con <a href="a"> Terminos y condiciones</a> </p>
       <input class="botons" type="submit" value="Registrar">
       <p><a href="#">Ya tengo una cuenta</a></p>
       </form>
    </section>
</body>
</html>
